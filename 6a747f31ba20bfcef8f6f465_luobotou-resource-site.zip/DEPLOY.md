# 公网部署说明

推荐部署到 Render，因为这个项目是带后端和文件上传功能的 Node.js 服务。

## 方式一：Render 部署

### 1. 上传到 GitHub

把当前项目上传到一个 GitHub 仓库。

需要上传的核心文件：

- `server.js`
- `package.json`
- `public/`
- `render.yaml`
- `Dockerfile`
- `.gitignore`

不要上传运行时产生的 `uploads/` 文件夹。

### 2. 创建 Render 服务

1. 打开 Render。
2. 新建 `Web Service`。
3. 连接你的 GitHub 仓库。
4. Render 会读取 `render.yaml`。
5. 部署完成后，Render 会给你一个公网地址。

### 3. 访问公网地址

部署完成后，公网地址类似：

```text
https://luobotou-resource-site.onrender.com
```

这个地址就是前端页面，手机浏览器也可以直接打开。

后端接口地址会是：

```text
https://你的域名/api/files
```

## 方式二：Docker 部署

如果你有云服务器，可以用 Docker 部署：

```bash
docker build -t luobotou-resource-site .
docker run -d \
  --name luobotou-resource-site \
  -p 3000:3000 \
  -v luobotou-resource-data:/app/data \
  -v luobotou-resource-uploads:/app/uploads \
  luobotou-resource-site
```

访问：

```text
http://服务器IP:3000
```

如果要绑定域名，建议再配置 Nginx 反向代理和 HTTPS。

## 环境变量

项目支持以下环境变量：

- `PORT`：服务端口，部署平台通常会自动设置
- `UPLOAD_DIR`：上传文件保存目录
- `DATA_FILE`：文件元数据 JSON 保存路径

Render 配置里已经设置：

```text
UPLOAD_DIR=/var/data/uploads
DATA_FILE=/var/data/data/files.json
```

## 注意

这个项目目前没有登录系统，公网部署后任何访问者都可以上传和删除文件。如果要公开给别人使用，建议下一步增加管理员密码或登录功能。
