const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_FILE = process.env.DATA_FILE || path.join(ROOT, 'data', 'files.json');
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
const MAX_UPLOAD_SIZE = 80 * 1024 * 1024;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xls': 'application/vnd.ms-excel',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.mp4': 'video/mp4',
  '.mp3': 'audio/mpeg'
};

function ensureStorage() {
  const dataDir = path.dirname(DATA_FILE);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  }

  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([], null, 2), 'utf8');
  }
}

function readFiles() {
  ensureStorage();
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw || '[]');
}

function writeFiles(files) {
  ensureStorage();
  fs.writeFileSync(DATA_FILE, JSON.stringify(files, null, 2), 'utf8');
}

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(JSON.stringify(payload));
}

function sendError(res, statusCode, message) {
  sendJson(res, statusCode, { error: message });
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;

    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_UPLOAD_SIZE) {
        reject(new Error('上传文件不能超过 80MB'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function parseMultipart(buffer, contentType) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  const boundary = boundaryMatch && (boundaryMatch[1] || boundaryMatch[2]);

  if (!boundary) {
    throw new Error('上传请求格式不正确');
  }

  const delimiter = Buffer.from(`--${boundary}`);
  const parts = [];
  let start = buffer.indexOf(delimiter);

  while (start !== -1) {
    start += delimiter.length;
    if (buffer[start] === 45 && buffer[start + 1] === 45) break;
    if (buffer[start] === 13 && buffer[start + 1] === 10) start += 2;

    const next = buffer.indexOf(delimiter, start);
    if (next === -1) break;

    let part = buffer.slice(start, next);
    if (part.length >= 2 && part[part.length - 2] === 13 && part[part.length - 1] === 10) {
      part = part.slice(0, -2);
    }

    const headerEnd = part.indexOf(Buffer.from('\r\n\r\n'));
    if (headerEnd !== -1) {
      const headerText = part.slice(0, headerEnd).toString('utf8');
      const body = part.slice(headerEnd + 4);
      const nameMatch = /name="([^"]+)"/i.exec(headerText);
      const fileNameMatch = /filename="([^"]*)"/i.exec(headerText);
      const typeMatch = /Content-Type:\s*([^\r\n]+)/i.exec(headerText);

      if (nameMatch) {
        parts.push({
          name: nameMatch[1],
          filename: fileNameMatch ? path.basename(fileNameMatch[1]) : '',
          contentType: typeMatch ? typeMatch[1].trim() : 'application/octet-stream',
          body
        });
      }
    }

    start = next;
  }

  return parts;
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function safeUploadName(originalName) {
  const ext = path.extname(originalName || '').toLowerCase();
  return `${Date.now()}-${crypto.randomUUID()}${ext}`;
}

function handleStatic(req, res) {
  const requestUrl = new URL(req.url, `http://${req.headers.host}`);
  const safePath = path.normalize(decodeURIComponent(requestUrl.pathname)).replace(/^(\.\.[/\\])+/, '');
  const filePath = path.join(PUBLIC_DIR, safePath === '/' ? 'index.html' : safePath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.stat(filePath, (statError, stats) => {
    if (statError || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('页面不存在');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
      'Cache-Control': ['.html', '.css', '.js'].includes(ext) ? 'no-cache' : 'public, max-age=3600'
    });
    fs.createReadStream(filePath).pipe(res);
  });
}

async function handleApi(req, res) {
  const requestUrl = new URL(req.url, `http://${req.headers.host}`);

  if (requestUrl.pathname === '/api/files' && req.method === 'GET') {
    const query = String(requestUrl.searchParams.get('q') || '').toLowerCase();
    const files = readFiles();

    const filtered = files.filter(item => {
      const haystack = [item.originalName, item.description, item.type].join(' ').toLowerCase();
      return !query || haystack.includes(query);
    });

    sendJson(res, 200, {
      files: filtered,
      total: filtered.length
    });
    return;
  }

  if (requestUrl.pathname === '/api/files' && req.method === 'POST') {
    try {
      const body = await readRawBody(req);
      const parts = parseMultipart(body, req.headers['content-type']);
      const filePart = parts.find(part => part.name === 'file' && part.filename);
      const descriptionPart = parts.find(part => part.name === 'description');

      if (!filePart || !filePart.body.length) {
        throw new Error('请选择要上传的文件');
      }

      ensureStorage();
      const storedName = safeUploadName(filePart.filename);
      const storedPath = path.join(UPLOAD_DIR, storedName);
      fs.writeFileSync(storedPath, filePart.body);

      const file = {
        id: crypto.randomUUID(),
        originalName: filePart.filename,
        storedName,
        type: filePart.contentType,
        size: filePart.body.length,
        sizeText: formatBytes(filePart.body.length),
        description: descriptionPart ? descriptionPart.body.toString('utf8').trim() : '',
        downloadUrl: `/api/files/${storedName}/download`,
        createdAt: new Date().toISOString()
      };

      const files = readFiles();
      files.unshift(file);
      writeFiles(files);
      sendJson(res, 201, file);
    } catch (error) {
      sendError(res, 400, error.message);
    }
    return;
  }

  const downloadMatch = /^\/api\/files\/([^/]+)\/download$/.exec(requestUrl.pathname);
  if (downloadMatch && req.method === 'GET') {
    const storedName = path.basename(decodeURIComponent(downloadMatch[1]));
    const files = readFiles();
    const file = files.find(item => item.storedName === storedName);

    if (!file) {
      sendError(res, 404, '没有找到这个文件');
      return;
    }

    const filePath = path.join(UPLOAD_DIR, file.storedName);
    if (!filePath.startsWith(UPLOAD_DIR) || !fs.existsSync(filePath)) {
      sendError(res, 404, '文件已不存在');
      return;
    }

    const encodedName = encodeURIComponent(file.originalName);
    res.writeHead(200, {
      'Content-Type': file.type || MIME_TYPES[path.extname(file.originalName).toLowerCase()] || 'application/octet-stream',
      'Content-Disposition': `attachment; filename*=UTF-8''${encodedName}`,
      'Content-Length': fs.statSync(filePath).size
    });
    fs.createReadStream(filePath).pipe(res);
    return;
  }

  if (requestUrl.pathname.startsWith('/api/files/') && req.method === 'DELETE') {
    const id = decodeURIComponent(requestUrl.pathname.split('/').pop());
    const files = readFiles();
    const file = files.find(item => item.id === id);

    if (!file) {
      sendError(res, 404, '没有找到这个文件');
      return;
    }

    const filePath = path.join(UPLOAD_DIR, file.storedName);
    if (filePath.startsWith(UPLOAD_DIR) && fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    writeFiles(files.filter(item => item.id !== id));
    sendJson(res, 200, { ok: true });
    return;
  }

  sendError(res, 404, '接口不存在');
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.url.startsWith('/api/')) {
      await handleApi(req, res);
      return;
    }

    handleStatic(req, res);
  } catch (error) {
    sendError(res, 500, error.message || '服务器错误');
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`资源站已启动：http://0.0.0.0:${PORT}`);
});
