# 萝卜头的资源站

一个带后端 API 的文件资源站网页，适合上传、展示、搜索、下载和删除文件资源。

## 功能

- 前端标题为“萝卜头的资源站”
- 圆角长方形文件卡片展示
- 右上角文件搜索
- 后端上传文件
- 前端查看文件信息
- 前端下载文件
- 后端删除文件并同步前端列表
- Node.js 后端 API
- JSON 文件元数据存储
- 零第三方依赖，部署简单

## 本地运行

```bash
npm start
```

启动后访问：

```text
http://localhost:3000
```

## 文件接口

### 获取文件列表

```http
GET /api/files
```

支持参数：

- `q`：按文件名、说明或类型搜索

### 上传文件

```http
POST /api/files
Content-Type: multipart/form-data
```

表单字段：

- `file`：要上传的文件
- `description`：文件说明

### 下载文件

```http
GET /api/files/:storedName/download
```

### 删除文件

```http
DELETE /api/files/:id
```

## 公网部署建议

### Render

1. 把项目上传到 GitHub。
2. 在 Render 新建 Web Service。
3. 选择这个仓库。
4. 设置启动命令：

```bash
npm start
```

5. Render 会自动分配公网访问地址。

### Railway

1. 把项目上传到 GitHub。
2. 在 Railway 新建项目并导入仓库。
3. Railway 会识别 Node.js 项目。
4. 启动命令使用：

```bash
npm start
```

### 服务器部署

如果你有云服务器，可以安装 Node.js 后运行：

```bash
npm start
```

生产环境建议配合 Nginx 反向代理，并使用 PM2 保持进程常驻。

## 后续可扩展

- 接入 SQLite、PostgreSQL 或 MongoDB
- 增加管理员登录
- 增加资源审核
- 增加上传封面图
- 增加收藏、点赞和访问统计
- 增加后台管理页面
