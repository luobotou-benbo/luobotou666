const state = {
  files: [],
  query: ''
};

const fileGrid = document.querySelector('#fileGrid');
const emptyState = document.querySelector('#emptyState');
const searchInput = document.querySelector('#searchInput');
const totalCount = document.querySelector('#totalCount');
const storageCount = document.querySelector('#storageCount');
const refreshBtn = document.querySelector('#refreshBtn');
const uploadForm = document.querySelector('#uploadForm');
const formMessage = document.querySelector('#formMessage');

function escapeHtml(value) {
  return String(value || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatDate(value) {
  return new Intl.DateTimeFormat('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date(value));
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function getFileExt(name) {
  const ext = String(name || '').split('.').pop();
  return ext && ext !== name ? ext.slice(0, 4).toUpperCase() : 'FILE';
}

function renderFiles() {
  totalCount.textContent = state.files.length;
  storageCount.textContent = formatBytes(state.files.reduce((sum, file) => sum + Number(file.size || 0), 0));

  if (!state.files.length) {
    fileGrid.innerHTML = '';
    emptyState.hidden = false;
    return;
  }

  emptyState.hidden = true;
  fileGrid.innerHTML = state.files.map(file => {
    return `
      <article class="file-card">
        <div class="card-top">
          <div class="file-icon">${escapeHtml(getFileExt(file.originalName))}</div>
          <small>${formatDate(file.createdAt)}</small>
        </div>
        <h3>${escapeHtml(file.originalName)}</h3>
        <div class="file-meta">
          <span>${escapeHtml(file.sizeText || formatBytes(file.size || 0))}</span>
          <span>${escapeHtml(file.type || '未知类型')}</span>
        </div>
        <p>${escapeHtml(file.description || '这个文件暂时还没有说明。')}</p>
        <div class="card-actions">
          <a class="download-link" href="${escapeHtml(file.downloadUrl)}">下载文件</a>
          <button class="delete-btn" type="button" data-id="${escapeHtml(file.id)}">删除</button>
        </div>
      </article>
    `;
  }).join('');
}

async function loadFiles() {
  const params = new URLSearchParams();
  if (state.query) params.set('q', state.query);

  const response = await fetch(`/api/files?${params.toString()}`);
  if (!response.ok) {
    throw new Error('加载文件失败');
  }

  const data = await response.json();
  state.files = data.files || [];
  renderFiles();
}

async function submitFile(event) {
  event.preventDefault();
  formMessage.textContent = '正在上传...';

  const formData = new FormData(uploadForm);

  try {
    const response = await fetch('/api/files', {
      method: 'POST',
      body: formData
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || '上传失败');
    }

    uploadForm.reset();
    formMessage.textContent = '上传成功，文件已显示在前端列表。';
    state.query = '';
    searchInput.value = '';
    await loadFiles();
  } catch (error) {
    formMessage.textContent = error.message;
  }
}

async function deleteFile(id) {
  const confirmed = window.confirm('确定要删除这个文件吗？删除后前端将无法下载。');
  if (!confirmed) return;

  const response = await fetch(`/api/files/${encodeURIComponent(id)}`, {
    method: 'DELETE'
  });

  if (!response.ok) {
    const data = await response.json();
    window.alert(data.error || '删除失败');
    return;
  }

  await loadFiles();
}

let searchTimer;
searchInput.addEventListener('input', event => {
  window.clearTimeout(searchTimer);
  searchTimer = window.setTimeout(() => {
    state.query = event.target.value.trim();
    loadFiles().catch(error => {
      formMessage.textContent = error.message;
    });
  }, 220);
});

refreshBtn.addEventListener('click', () => {
  loadFiles().catch(error => {
    formMessage.textContent = error.message;
  });
});

fileGrid.addEventListener('click', event => {
  const deleteButton = event.target.closest('.delete-btn');
  if (!deleteButton) return;
  deleteFile(deleteButton.dataset.id).catch(error => {
    formMessage.textContent = error.message;
  });
});

uploadForm.addEventListener('submit', submitFile);

loadFiles().catch(error => {
  formMessage.textContent = error.message;
});
